public class Vehicles extends RentalItem {
    double pricePerDay;

    public Vehicles(String id, String brand, String model, double pricePerDay) {
        super(id, brand, model);
        this.pricePerDay = pricePerDay;
    }

   
    public String toString() {
        return super.toString() + ", Price Per Day: R" + pricePerDay;
    }
}