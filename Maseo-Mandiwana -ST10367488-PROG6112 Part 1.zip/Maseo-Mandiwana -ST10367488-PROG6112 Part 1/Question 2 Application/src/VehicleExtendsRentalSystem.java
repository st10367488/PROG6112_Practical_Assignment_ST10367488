
import java.util.ArrayList;
import java.util.List;

public class VehicleExtendsRentalSystem {

    public ArrayList<Vehicle> vehicles = new ArrayList<>();
    public ArrayList<Rental> activeRentals = new ArrayList<>();
    public ArrayList<Rental> completedRentals = new ArrayList<>();

    public VehicleExtendsRentalSystem() {
        vehicles.add(new Vehicle("V001", "Toyota", "Corolla", 500));
        vehicles.add(new Vehicle("V002", "Tesla", "Model 3", 100));
        vehicles.add(new Vehicle("V003", "Honda", "Civic", 400));
    }

    public void addVehicle(String id, String brand, String model, double pricePerDay) {
        vehicles.add(new Vehicle(id, brand, model, pricePerDay));
        System.out.println("Vehicle added successfully!");
    }

    public void listAvailableVehicles() {
        System.out.println("Available Vehicles:");
        for (Vehicle vehicle : vehicles) {
            if (!vehicle.isRented()) {
                System.out.println(vehicle);
            }
        }
    }

    public void rentVehicle(String vehicleId, String customerId, int rentalDays) {
        for (Vehicle vehicle : vehicles) {
            if (vehicle.getId().equals(vehicleId) && !vehicle.isRented()) {
                Rental rental = new Rental(customerId, vehicle, rentalDays);
                activeRentals.add(rental);
                vehicle.setRented(true);
                System.out.println("Vehicle rented successfully!");
                return;
            }
        }
        System.out.println("Vehicle not available for rent.");
    }

    public void returnVehicle(String customerId) {
        for (Rental rental : activeRentals) {
            if (rental.getCustomerId().equals(customerId)) {
                completedRentals.add(rental);
                rental.getVehicle().setRented(false);
                activeRentals.remove(rental);
                System.out.println("Vehicle returned successfully! Total Fee: R" + rental.calculateFee());
                return;
            }
        }
        System.out.println("No active rentals found for this customer ID.");
    }

    public void generateActiveRentalsReport() {
        System.out.println("Active Rentals Report:");
        for (Rental rental : activeRentals) {
            System.out.println(rental);
        }
    }

    public void generateCompletedRentalsReport() {
        System.out.println("Completed Rentals Report:");
        for (Rental rental : completedRentals) {
            System.out.println(rental);
        }
    }

    public void exitSystem() {
        System.out.println("Exiting Vehicle Rental System. Goodbye!");
        System.exit(0);
    }

    
    public List<Vehicle> getVehicles() {
        return vehicles;
    }

    public List<Rental> getActiveRentals() {
        return activeRentals;

    }
}
