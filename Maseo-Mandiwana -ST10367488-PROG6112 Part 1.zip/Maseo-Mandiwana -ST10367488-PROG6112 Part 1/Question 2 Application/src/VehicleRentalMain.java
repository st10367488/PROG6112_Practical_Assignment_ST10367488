
import java.util.Scanner;

public class VehicleRentalMain {

    public static void main(String[] args) {
        VehicleRentalSystem system = new VehicleRentalSystem();
        Scanner scanner = new Scanner(System.in);
        
        //Multiple if statements and a loop
        //Stackoverflow
        //By Eritrean
        // https://stackoverflow.com/users/5176992/eritrean

        while (true) {
            System.out.println("\nVEHICLE RENTAL SYSTEM");
            System.out.println("1. Add New Vehicle");
            System.out.println("2. List Available Vehicles");
            System.out.println("3. Rent a Vehicle");
            System.out.println("4. Return a Vehicle");
            System.out.println("5. Active Rentals Report");
            System.out.println("6. Exit");
            System.out.print("Choose an option: ");

            int choice = Integer.parseInt(scanner.nextLine());

            switch (choice) {
                case 1:
                    system.addVehicle();
                    break;
                case 2:
                    system.listAvailableVehicles();
                    break;
                case 3:
                    system.rentVehicle();
                    break;
                case 4:
                    system.returnVehicle();
                    break;
                case 5:
                    system.generateActiveRentalsReport();
                    break;
                case 6:
                    system.exitSystem();
                    break;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }
}
