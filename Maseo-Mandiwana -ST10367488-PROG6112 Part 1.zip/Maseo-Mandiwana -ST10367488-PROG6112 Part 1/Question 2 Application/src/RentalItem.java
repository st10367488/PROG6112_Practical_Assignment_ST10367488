class RentalItem {
    
   
    protected String id;
    protected String brand;
    protected String model;
    protected boolean isRented;

    public RentalItem(String id, String brand, String model) {
        this.id = id;
        this.brand = brand;
        this.model = model;
        this.isRented = false;
    }
    

    public void setRented(boolean isRented) {
        this.isRented = isRented;
    }

   
    
    public String toString() {
        return "ID: " + id + ", Brand: " + brand + ", Model: " + model + ", Available: " + (!isRented);
    }
}
