
import java.util.ArrayList;
import java.util.Scanner;

class Vehicle {

    String id;
    String brand;
    String model;
    double pricePerDay;
    boolean isRented;

    public boolean isRented() {
        return isRented;
    }

    public void setRented(boolean rented) {
        isRented = rented;
    }

    public Vehicle(String id, String brand, String model, double pricePerDay) {
        this.id = id;
        this.brand = brand;
        this.model = model;
        this.pricePerDay = pricePerDay;
        this.isRented = false;
    }

    public String getId() {
        return id;
    }

    public String getBrand() {
        return brand;
    }

    public String getModel() {
        return model;
    }

    public double getPricePerDay() {
        return pricePerDay;
    }

    @Override
    public String toString() {
        return "Vehicle ID: " + id + ", Brand: " + brand + ", Model: " + model + ", Price Per Day: R" + pricePerDay + ", Available: " + (!isRented);
    }

}

class Rental {

    String customerId;
    Vehicle vehicle;
    int rentalDays;

    public Rental(String customerId, Vehicle vehicle, int rentalDays) {
        this.customerId = customerId;
        this.vehicle = vehicle;
        this.rentalDays = rentalDays;
        this.vehicle.isRented = true;
    }

    public double calculateFee() {
        return rentalDays * vehicle.pricePerDay;
    }

    @Override
    public String toString() {
        return "Customer ID: " + customerId + ", Vehicle: " + vehicle.brand + " " + vehicle.model + ", Days Rented: " + rentalDays + ", Fee: $" + calculateFee();
    }
}

class VehicleRentalSystem {

    
    // Converting an array to a list
    //CodeGym
    //By Volodymyr Portianko
    //https://codegym.cc/groups/posts/add-new-element-to-array
    
    
    public ArrayList<Vehicle> vehicles = new ArrayList<>();
    public ArrayList<Rental> activeRentals = new ArrayList<>();
    public ArrayList<Rental> completedRentals = new ArrayList<>();

  
    public VehicleRentalSystem() {
        vehicles.add(new Vehicle("V001", "Toyota", "Corolla", 50));
        vehicles.add(new Vehicle("V002", "Tesla", "Model 3", 100));
        vehicles.add(new Vehicle("V003", "Honda", "Civic", 40));

    }

    public void addVehicle() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter vehicle ID: ");
        String id = scanner.nextLine();
        System.out.print("Enter vehicle brand: ");
        String brand = scanner.nextLine();
        System.out.print("Enter vehicle model: ");
        String model = scanner.nextLine();
        System.out.print("Enter price per day: ");
        double pricePerDay = Double.parseDouble(scanner.nextLine());

        vehicles.add(new Vehicle(id, brand, model, pricePerDay));
        System.out.println("Vehicle added successfully!");
    }

    public void listAvailableVehicles() {
        System.out.println("Available Vehicles:");
        for (Vehicle vehicle : vehicles) {
            if (!vehicle.isRented) {
                System.out.println(vehicle);
            }
        }
    }

    public void rentVehicle() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter customer ID: ");
        String customerId = scanner.nextLine();

        listAvailableVehicles();

        System.out.print("Enter vehicle ID to rent: ");
        String vehicleId = scanner.nextLine();
        System.out.print("Enter number of rental days: ");
        int rentalDays = Integer.parseInt(scanner.nextLine());

        for (Vehicle vehicle : vehicles) {
            if (vehicle.id.equals(vehicleId) && !vehicle.isRented) {
                Rental rental = new Rental(customerId, vehicle, rentalDays);
                activeRentals.add(rental);
                System.out.println("Vehicle rented successfully!");
                return;
            }
        }
        System.out.println("Vehicle not available for rent.");
    }

    public void returnVehicle() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter customer ID: ");
        String customerId = scanner.nextLine();

        for (Rental rental : activeRentals) {
            if (rental.customerId.equals(customerId)) {
                completedRentals.add(rental);
                rental.vehicle.isRented = false;
                activeRentals.remove(rental);
                System.out.println("Vehicle returned successfully! Total Fee: $" + rental.calculateFee());
                return;
            }
        }
        System.out.println("No active rentals found for this customer ID.");
    }

    public void generateActiveRentalsReport() {
        System.out.println("Active Rentals Report:");
        for (Rental rental : activeRentals) {
            System.out.println(rental);
        }
    }

    public void generateCompletedRentalsReport() {
        System.out.println("Completed Rentals Report:");
        for (Rental rental : completedRentals) {
            System.out.println(rental);
        }
    }

    public void exitSystem() {
        System.out.println("Exiting Vehicle Rental System. Goodbye!");
        System.exit(0);
    }
}
