
public class Rental {

    private String customerId;
    private Vehicle vehicle;
    private int rentalDays;

    public Rental(String customerId, Vehicle vehicle, int rentalDays) {
        this.customerId = customerId;
        this.vehicle = vehicle;
        this.rentalDays = rentalDays;
    }

    public String getCustomerId() {
        return customerId;
    }

    public Vehicle getVehicle() {
        return vehicle;
    }

    public int getRentalDays() {
        return rentalDays;
    }

    public double calculateFee() {
        return vehicle.getPricePerDay() * rentalDays;
    }

    @Override
    public String toString() {
        return "Rental{customerId='" + customerId + "', vehicle=" + vehicle + ", rentalDays=" + rentalDays + ", fee=" + calculateFee() + "}";
    }

}
