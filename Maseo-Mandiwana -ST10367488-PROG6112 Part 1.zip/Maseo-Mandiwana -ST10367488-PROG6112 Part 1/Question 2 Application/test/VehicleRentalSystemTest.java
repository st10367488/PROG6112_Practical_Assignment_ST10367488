/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Maseo Junior
 */
public class VehicleRentalSystemTest {
    
    public VehicleRentalSystemTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of addVehicle method, of class VehicleRentalSystem.
     */
    @Test
    public void testAddVehicle() {
        System.out.println("addVehicle");
        VehicleRentalSystem instance = new VehicleRentalSystem();
        instance.addVehicle();
       
    }

    /**
     * Test of listAvailableVehicles method, of class VehicleRentalSystem.
     */
    @Test
    public void testListAvailableVehicles() {
        System.out.println("listAvailableVehicles");
        VehicleRentalSystem instance = new VehicleRentalSystem();
        instance.listAvailableVehicles();
       
    }

    /**
     * Test of rentVehicle method, of class VehicleRentalSystem.
     */
    @Test
    public void testRentVehicle() {
        System.out.println("rentVehicle");
        VehicleRentalSystem instance = new VehicleRentalSystem();
        instance.rentVehicle();
       
    }

    /**
     * Test of returnVehicle method, of class VehicleRentalSystem.
     */
    @Test
    public void testReturnVehicle() {
        System.out.println("returnVehicle");
        VehicleRentalSystem instance = new VehicleRentalSystem();
        instance.returnVehicle();
      
    }

    /**
     * Test of generateActiveRentalsReport method, of class VehicleRentalSystem.
     */
    @Test
    public void testGenerateActiveRentalsReport() {
        System.out.println("generateActiveRentalsReport");
        VehicleRentalSystem instance = new VehicleRentalSystem();
        instance.generateActiveRentalsReport();
       
    }

    /**
     * Test of generateCompletedRentalsReport method, of class VehicleRentalSystem.
     */
    @Test
    public void testGenerateCompletedRentalsReport() {
        System.out.println("generateCompletedRentalsReport");
        VehicleRentalSystem instance = new VehicleRentalSystem();
        instance.generateCompletedRentalsReport();
        
    }

    /**
     * Test of exitSystem method, of class VehicleRentalSystem.
     */
    @Test
    public void testExitSystem() {
        System.out.println("exitSystem");
        VehicleRentalSystem instance = new VehicleRentalSystem();
        instance.exitSystem();
        
    }
    
}
