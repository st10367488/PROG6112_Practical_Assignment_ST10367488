
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;
import java.util.List;

public class VehicleExtendsRentalSystemTest {

    private VehicleExtendsRentalSystem system;

    @Before
    public void setUp() {
        system = new VehicleExtendsRentalSystem();
    }

    @Test
    public void testAddVehicle() {

        String id = "V004";
        String brand = "Ford";
        String model = "Mustang";
        double pricePerDay = 75.0;

        system.addVehicle(id, brand, model, pricePerDay);

        List<Vehicle> vehicles = system.getVehicles();
        assertEquals(4, vehicles.size());

        Vehicle addedVehicle = vehicles.get(3);
        assertEquals(id, addedVehicle.getId());
        assertEquals(brand, addedVehicle.getBrand());
        assertEquals(model, addedVehicle.getModel());
        assertEquals(pricePerDay, addedVehicle.getPricePerDay(), 0.01);
    }

    @Test
    public void testRentVehicle() {

        system.addVehicle("V005", "Chevrolet", "Impala", 60.0);

        system.rentVehicle("V005", "C001", 3);

        List<Rental> activeRentals = system.getActiveRentals();
        assertEquals(1, activeRentals.size());

        Rental rental = activeRentals.get(0);
        assertEquals("C001", rental.getCustomerId());
        assertEquals("V005", rental.getVehicle().getId());
        assertEquals(3, rental.getRentalDays());
    }

    @Test
    public void testGenerateActiveRentalsReport() {

        system.addVehicle("V007", "Audi", "Q7", 85.0);
        system.rentVehicle("V007", "C003", 2);

        system.generateActiveRentalsReport();
    }

    @Test
    public void testGenerateCompletedRentalsReport() {

        system.addVehicle("V008", "Nissan", "Altima", 70.0);
        system.rentVehicle("V008", "C004", 4);
        system.returnVehicle("C004");

        system.generateCompletedRentalsReport();
    }
}
