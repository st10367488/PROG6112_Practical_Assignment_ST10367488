
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import javax.swing.JOptionPane;
import static org.junit.Assert.*;

public class StudentTest {

    Student studentApp;

    @Before
    public void setUp() {
        studentApp = new Student();
    }

    @After
    public void tearDown() {
        studentApp = null;
    }

    @Test
    public void testSaveStudent() {
        String id = "101";
        String name = "John Doe";
        int age = 20;
        String email = "john@example.com";
        String course = "Computer Science";

        studentApp.students.add(new StudentStore(id, name, age, email, course));
        StudentStore savedStudent = studentApp.students.get(0);

        assertEquals("101", savedStudent.getId());
        assertEquals("John Doe", savedStudent.name);
        assertEquals(20, savedStudent.age);
        assertEquals("john@example.com", savedStudent.email);
        assertEquals("Computer Science", savedStudent.course);

        System.out.println("Student Saved:");
        System.out.println("ID: " + savedStudent.getId());
        System.out.println("Name: " + savedStudent.name);
        System.out.println("Age: " + savedStudent.age);
        System.out.println("Email: " + savedStudent.email);
        System.out.println("Course: " + savedStudent.course);
    }

    @Test
    public void testSearchStudent() {
        studentApp.students.add(new StudentStore("101", "John Doe", 20, "john@example.com", "Computer Science"));
        studentApp.students.add(new StudentStore("102", "Jane Doe", 22, "jane@example.com", "Information Technology"));

        String searchId = "102";
        StudentStore foundStudent = null;

        for (StudentStore student : studentApp.students) {
            if (student.getId().equals(searchId)) {
                foundStudent = student;
                break;
            }
        }

        assertNotNull("Student should be found", foundStudent);
        assertEquals("102", foundStudent.getId());
        assertEquals("Jane Doe", foundStudent.name);
        assertEquals(22, foundStudent.age);
        assertEquals("jane@example.com", foundStudent.email);
        assertEquals("Information Technology", foundStudent.course);

        System.out.println("Student Found:");
        System.out.println("ID: " + foundStudent.getId());
        System.out.println("Name: " + foundStudent.name);
        System.out.println("Age: " + foundStudent.age);
        System.out.println("Email: " + foundStudent.email);
        System.out.println("Course: " + foundStudent.course);
    }

    @Test
    public void testSearchStudent_StudentNotFound() {
        studentApp.students.add(new StudentStore("101", "John Doe", 20, "john@example.com", "Computer Science"));
        studentApp.students.add(new StudentStore("102", "Jane Doe", 22, "jane@example.com", "Information Technology"));

        String searchId = "999";
        boolean studentFound = false;
        String studentDetails = "";

        for (StudentStore student : studentApp.students) {
            if (student.getId().equals(searchId)) {
                studentDetails = student.toString();
                studentFound = true;
                break;
            }
        }

        assertFalse("Student should not be found", studentFound);
        assertEquals("", studentDetails);

        if (!studentFound) {
            JOptionPane.showMessageDialog(null, "Student with ID " + searchId + " was not found.", "Student Not Found", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(null, "Error: Student found unexpectedly.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    @Test
    public void testDeleteStudent() {
        studentApp.students.add(new StudentStore("101", "John Doe", 20, "john@example.com", "Computer Science"));
        studentApp.students.add(new StudentStore("102", "Jane Doe", 22, "jane@example.com", "Information Technology"));
        assertEquals(2, studentApp.students.size());

        String deleteId = "102";
        boolean studentDeleted = false;

        for (StudentStore student : studentApp.students) {
            if (student.getId().equals(deleteId)) {
                studentApp.students.remove(student);
                studentDeleted = true;
                break;
            }
        }

        assertTrue("Student should be deleted", studentDeleted);
        assertEquals("101", studentApp.students.get(0).getId());

        if (studentDeleted) {
            System.out.println("Student with ID " + deleteId + " successfully deleted.");
        } else {
            System.out.println("Student with ID " + deleteId + " not found.");
        }
    }

    @Test
    public void testDeleteStudent_StudentNotFound() {
        studentApp.students.add(new StudentStore("101", "John Doe", 20, "john@example.com", "Computer Science"));
        studentApp.students.add(new StudentStore("102", "Jane Doe", 22, "jane@example.com", "Information Technology"));

        String deleteId = "999";
        boolean studentDeleted = false;

        for (StudentStore student : studentApp.students) {
            if (student.getId().equals(deleteId)) {
                studentApp.students.remove(student);
                studentDeleted = true;
                break;
            }
        }

        assertFalse("No student should be deleted", studentDeleted);
        assertEquals(2, studentApp.students.size());

        if (!studentDeleted) {
            JOptionPane.showMessageDialog(null, "Student with ID " + deleteId + " was not found and could not be deleted.", "Student Not Found", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(null, "Error: Deletion failed as the specified student could not be located.", "Error", JOptionPane.ERROR_MESSAGE);

        }
    }

    @Test
    public void TestStudentAge_StudentAgeValid() {
        studentApp.students.add(new StudentStore("101", "John Doe", 20, "john@example.com", "Computer Science"));
        studentApp.students.add(new StudentStore("102", "Jane Doe", 22, "jane@example.com", "Information Technology"));

        String Age = "20";
        boolean studentAgeValid = false;

        for (StudentStore student : studentApp.students) {
            if (student.getId().equals(Age)) {
                studentApp.students.remove(student);
                studentAgeValid = true;
                break;

            }
        }

        assertFalse("Student Age should be valid", studentAgeValid);
        assertEquals(2, studentApp.students.size());

        if (!studentAgeValid) {
            JOptionPane.showMessageDialog(null, "Student Age " + Age + " is valid.", " ", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    @Test
    public void TestStudentAge_StudentAgeInValid() {
        studentApp.students.add(new StudentStore("101", "John Doe", 10, "john@example.com", "Computer Science"));
        studentApp.students.add(new StudentStore("102", "Jane Doe", 2, "jane@example.com", "Information Technology"));

       boolean studentAgeInValid = false;

  
    
        for (StudentStore student : studentApp.students) {
            System.out.println("Checking student: " + student.getName() + ", Age: " + student.age);
            if (student.age < 16) {
                System.out.println("Invalid student found: " + student.getName() + " with Age: " + student.age);
                studentAgeInValid = true;

               
                JOptionPane.showMessageDialog(null, "Invalid student found: " + student.getName() + " with Age: " + student.age, "Invalid Student", JOptionPane.INFORMATION_MESSAGE);
                break;
            }
        }

        System.out.println("Student age invalid flag: " + studentAgeInValid);
        
        
        assertTrue("Student age should be invalid", studentAgeInValid);

        
        if (!studentAgeInValid) {
            JOptionPane.showMessageDialog(null, "No students with invalid age found.", "Validation Complete", JOptionPane.INFORMATION_MESSAGE);
        }
        
        
}
}
