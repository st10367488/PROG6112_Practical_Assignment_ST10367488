import java.util.Scanner;

public class StudentMain {

    public static void main(String[] args) {
        Student student = new Student(); // Assuming this class contains all the necessary methods
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("STUDENT APPLICATION");
            System.out.println("Enter (1) to launch menu or any other key to exit.");
            String input = scanner.nextLine();

            if (input.equals("1")) {
                while (true) {
                    System.out.println("Please select one of the following menu items:");
                    System.out.println("(1) Capture a new student.");
                    System.out.println("(2) Search for a student.");
                    System.out.println("(3) Delete a student.");
                    System.out.println("(4) Print student report.");
                    System.out.println("(5) Exit application.");

                    String menuOption = scanner.nextLine();

                    int x = 0;
                    try {
                        x = Integer.parseInt(menuOption); 
                    } catch (NumberFormatException e) {
                        System.out.println("Invalid input, Please enter a number.");
                       
                    }

                    
                    if (x == 1) {
                        student.saveStudent();
                    } else if (x == 2) {
                        student.searchStudent();
                    } else if (x == 3) {
                        student.deleteStudent();
                    } else if (x == 4) {
                        student.studentReport();
                    } else if (x == 5) {
                        student.exitStudentApplication();
                    } else {
                        
                        System.out.println("Invalid option, Please try again.");
                    }
                }
            } else {
                student.exitStudentApplication();
            }
        }
    }
}
