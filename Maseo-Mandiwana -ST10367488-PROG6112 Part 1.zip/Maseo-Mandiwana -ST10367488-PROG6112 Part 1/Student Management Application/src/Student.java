
import java.util.ArrayList;
import java.util.Scanner;


class Student {
    
    //The code to store an object in Arraylist
    // Stackoverflow
    // By Festus Tamakloe
    //https://stackoverflow.com/users/1562558/festus-tamakloe
 
    public ArrayList<StudentStore> students = new ArrayList<>();
    public Scanner scanner = new Scanner(System.in);

    public void saveStudent() {
        System.out.print("Enter the student ID: ");
        String id = scanner.nextLine();

        System.out.print("Enter the student name: ");
        String name = scanner.nextLine();

       
        while (true) {
            System.out.print("Enter the student age: ");
             if (scanner.hasNextInt()){
                 int age = scanner.nextInt();
                 if (age >= 16){
                     break;
                 }else{
                     System.out.println("Incorrect age, Please enter age from 16 or older.");
                 }
                }else{
                  System.out.println("Incorrect input, Please enter a correct number.");
                  scanner.next(); 

            }
        }
        
        
        
         int age = 0;
        System.out.print("Enter the student email: ");
        String email = scanner.nextLine();

        System.out.print("Enter the student course: ");
        String course = scanner.nextLine();

        students.add(new StudentStore(id, name, age, email, course));
        System.out.println("Student captured successfully!");
    }

    
    // Method for searching through an array
    //Stackoverflow
    //By Fulltimehustle
    //https://stackoverflow.com/users/1562558/festus-tamakloe
    public void searchStudent() {
        System.out.print("Enter the student ID to search: ");
        String id = scanner.nextLine();

        for (StudentStore student : students) {
            if (student.getId().equals(id)) {
                System.out.println("Student found: " + student);
                return;
            }
        }
        System.out.println("Student not found.");
    }

    public void deleteStudent() {
        System.out.print("Enter the student ID to delete: ");
        String id = scanner.nextLine();

        for (StudentStore student : students) {
            if (student.getId().equals(id)) {
                students.remove(student);
                System.out.println("Student deleted successfully.");
                return;
            }
        }
        System.out.println("Student not found.");
    }

    public void studentReport() {
        System.out.println("Student Report:");
        if (students.isEmpty()) {
            System.out.println("No students to display.");
        } else {
            for (StudentStore student : students) {
                System.out.println(student);
            }
        }
    }

    public void exitStudentApplication() {
        System.out.println("Thank you, Bye!");
        System.exit(0);
    }
}

class StudentStore {

    String id;
    String name;
    int age;
    String email;
    String course;

    public StudentStore(String id, String name, int age, String email, String course) {
        this.id = id;
        this.name = name;
        this.age = age;
        this.email = email;
        this.course = course;
    }
    
     public String getName() {
        return name;
    }

    public String getId() {
        return id;
    }

    public String toString() {
        return "ID: " + id + ", Name: " + name + ", Age: " + age + ", Email: " + email + ", Course: " + course;
    }
}
